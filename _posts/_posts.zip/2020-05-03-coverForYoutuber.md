---
layout: post
title: " Youtube Computer Recoding with Cover(컴퓨터로 유튜브 영상을 녹화할때 보이고싶지 않은 부분을 가려주는 프로그램) "
categories: c#
author: boki
tags: c# youtube thumb 유튜브 썸네일
comments: true
sitemap :
  changefreq : daily
  priority : 1.0
---

## Youtube Computer Recoding with Cover

#### 컴퓨터로 유튜브 영상을 녹화할때 보이고싶지 않은 부분을 가려주는 프로그램입니다!!
#### 프로그램 종료시 크기를 기억하며, 도움창을 다시 열지 않음 눌렀음에도, 2일동안 프로그램을 사용하지 않는다면 다시 창이 뜨게 됩니다! 계속 사용해주세요
#### 프로그램 문의, 광고 문의는 lsb530@naver.com로 주시면 됩니다^^
### 다운로드 링크 첨부 밑에!!!

### CoverAreaForYoutuber 아래 클릭
[CoverAreaForYoutuber.zip](https://github.com/lsb530/lsb530.github.io/files/4588701/CoverAreaForYoutuber.zip)