---
layout: post
title: " 처음으로 Markdown 포스팅 작성 "
categories: Technology
author: boki
tags: Technology jekyll Markdown
comments: true
sitemap :
  changefreq : daily
  priority : 1.0
# excerpt: from jekyll 발췌
# matajax: true 수학식을 그리는 마크다운문법
---
* content
{:toc}

## 처음으로 Markdown 포스팅 작성

* 마크다운 문법으로 작성하고 있습니다. 

* 신기하군요 ^^

* : `*`

<br>

# 큰거 `#`
## 보통(헤드라인 밑줄 생김) `##`

내용입니다아아아

---

### 작은거 `###`

### `하얗게 들어가네요`

인용 : `>`
>>>> 인용문 사용! 이것은 검색으로부터 왔다


[커리사진](http://thumb.mtstarnews.com/06/2017/06/2017062209353988136_1.jpg)

![](http://thumb.mtstarnews.com/06/2017/06/2017062209353988136_1.jpg)

```
C:/Test/Test중입니다아아
```

```html
<a href="https://www.google.co.kr/" target="_blank">GOOGLE</a>
```

```css
.list > li {
  position: absolute;
  top: 40px;
}
```

```javascript
function func() {
  var a = 'AAA';
  return a;
}
```

```
Level 2 :       Dev -- Feature/login
        :           -- Feature/logout
Level 1 : Master
```

```ruby
def print_hi(name)
  puts "Hi, #{name}"
end
print_hi('Tom')
#=> prints 'Hi, Tom' to STDOUT.
```